```python
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
import seaborn as sns

from warnings import filterwarnings
filterwarnings(action='ignore')
```


```python
wine = pd.read_csv("winequality-red.csv")
wine.sample(25)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>fixed acidity</th>
      <th>volatile acidity</th>
      <th>citric acid</th>
      <th>residual sugar</th>
      <th>chlorides</th>
      <th>free sulfur dioxide</th>
      <th>total sulfur dioxide</th>
      <th>density</th>
      <th>pH</th>
      <th>sulphates</th>
      <th>alcohol</th>
      <th>quality</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>499</th>
      <td>8.7</td>
      <td>0.690</td>
      <td>0.31</td>
      <td>3.00</td>
      <td>0.086</td>
      <td>23.0</td>
      <td>81.0</td>
      <td>1.00020</td>
      <td>3.48</td>
      <td>0.74</td>
      <td>11.6</td>
      <td>6</td>
    </tr>
    <tr>
      <th>104</th>
      <td>7.2</td>
      <td>0.490</td>
      <td>0.24</td>
      <td>2.20</td>
      <td>0.070</td>
      <td>5.0</td>
      <td>36.0</td>
      <td>0.99600</td>
      <td>3.33</td>
      <td>0.48</td>
      <td>9.4</td>
      <td>5</td>
    </tr>
    <tr>
      <th>98</th>
      <td>7.6</td>
      <td>0.900</td>
      <td>0.06</td>
      <td>2.50</td>
      <td>0.079</td>
      <td>5.0</td>
      <td>10.0</td>
      <td>0.99670</td>
      <td>3.39</td>
      <td>0.56</td>
      <td>9.8</td>
      <td>5</td>
    </tr>
    <tr>
      <th>1421</th>
      <td>7.5</td>
      <td>0.400</td>
      <td>0.18</td>
      <td>1.60</td>
      <td>0.079</td>
      <td>24.0</td>
      <td>58.0</td>
      <td>0.99650</td>
      <td>3.34</td>
      <td>0.58</td>
      <td>9.4</td>
      <td>5</td>
    </tr>
    <tr>
      <th>618</th>
      <td>11.4</td>
      <td>0.460</td>
      <td>0.50</td>
      <td>2.70</td>
      <td>0.122</td>
      <td>4.0</td>
      <td>17.0</td>
      <td>1.00060</td>
      <td>3.13</td>
      <td>0.70</td>
      <td>10.2</td>
      <td>5</td>
    </tr>
    <tr>
      <th>1346</th>
      <td>6.1</td>
      <td>0.590</td>
      <td>0.01</td>
      <td>2.10</td>
      <td>0.056</td>
      <td>5.0</td>
      <td>13.0</td>
      <td>0.99472</td>
      <td>3.52</td>
      <td>0.56</td>
      <td>11.4</td>
      <td>5</td>
    </tr>
    <tr>
      <th>751</th>
      <td>8.3</td>
      <td>0.650</td>
      <td>0.10</td>
      <td>2.90</td>
      <td>0.089</td>
      <td>17.0</td>
      <td>40.0</td>
      <td>0.99803</td>
      <td>3.29</td>
      <td>0.55</td>
      <td>9.5</td>
      <td>5</td>
    </tr>
    <tr>
      <th>1513</th>
      <td>6.4</td>
      <td>0.560</td>
      <td>0.15</td>
      <td>1.80</td>
      <td>0.078</td>
      <td>17.0</td>
      <td>65.0</td>
      <td>0.99294</td>
      <td>3.33</td>
      <td>0.60</td>
      <td>10.5</td>
      <td>6</td>
    </tr>
    <tr>
      <th>64</th>
      <td>7.2</td>
      <td>0.725</td>
      <td>0.05</td>
      <td>4.65</td>
      <td>0.086</td>
      <td>4.0</td>
      <td>11.0</td>
      <td>0.99620</td>
      <td>3.41</td>
      <td>0.39</td>
      <td>10.9</td>
      <td>5</td>
    </tr>
    <tr>
      <th>62</th>
      <td>7.5</td>
      <td>0.520</td>
      <td>0.16</td>
      <td>1.90</td>
      <td>0.085</td>
      <td>12.0</td>
      <td>35.0</td>
      <td>0.99680</td>
      <td>3.38</td>
      <td>0.62</td>
      <td>9.5</td>
      <td>7</td>
    </tr>
    <tr>
      <th>713</th>
      <td>8.0</td>
      <td>0.430</td>
      <td>0.36</td>
      <td>2.30</td>
      <td>0.075</td>
      <td>10.0</td>
      <td>48.0</td>
      <td>0.99760</td>
      <td>3.34</td>
      <td>0.46</td>
      <td>9.4</td>
      <td>5</td>
    </tr>
    <tr>
      <th>878</th>
      <td>8.8</td>
      <td>0.610</td>
      <td>0.19</td>
      <td>4.00</td>
      <td>0.094</td>
      <td>30.0</td>
      <td>69.0</td>
      <td>0.99787</td>
      <td>3.22</td>
      <td>0.50</td>
      <td>10.0</td>
      <td>6</td>
    </tr>
    <tr>
      <th>429</th>
      <td>12.8</td>
      <td>0.840</td>
      <td>0.63</td>
      <td>2.40</td>
      <td>0.088</td>
      <td>13.0</td>
      <td>35.0</td>
      <td>0.99970</td>
      <td>3.10</td>
      <td>0.60</td>
      <td>10.4</td>
      <td>6</td>
    </tr>
    <tr>
      <th>893</th>
      <td>7.2</td>
      <td>0.660</td>
      <td>0.03</td>
      <td>2.30</td>
      <td>0.078</td>
      <td>16.0</td>
      <td>86.0</td>
      <td>0.99743</td>
      <td>3.53</td>
      <td>0.57</td>
      <td>9.7</td>
      <td>5</td>
    </tr>
    <tr>
      <th>669</th>
      <td>11.3</td>
      <td>0.340</td>
      <td>0.45</td>
      <td>2.00</td>
      <td>0.082</td>
      <td>6.0</td>
      <td>15.0</td>
      <td>0.99880</td>
      <td>2.94</td>
      <td>0.66</td>
      <td>9.2</td>
      <td>6</td>
    </tr>
    <tr>
      <th>877</th>
      <td>7.7</td>
      <td>0.715</td>
      <td>0.01</td>
      <td>2.10</td>
      <td>0.064</td>
      <td>31.0</td>
      <td>43.0</td>
      <td>0.99371</td>
      <td>3.41</td>
      <td>0.57</td>
      <td>11.8</td>
      <td>6</td>
    </tr>
    <tr>
      <th>559</th>
      <td>13.0</td>
      <td>0.470</td>
      <td>0.49</td>
      <td>4.30</td>
      <td>0.085</td>
      <td>6.0</td>
      <td>47.0</td>
      <td>1.00210</td>
      <td>3.30</td>
      <td>0.68</td>
      <td>12.7</td>
      <td>6</td>
    </tr>
    <tr>
      <th>1585</th>
      <td>7.2</td>
      <td>0.390</td>
      <td>0.44</td>
      <td>2.60</td>
      <td>0.066</td>
      <td>22.0</td>
      <td>48.0</td>
      <td>0.99494</td>
      <td>3.30</td>
      <td>0.84</td>
      <td>11.5</td>
      <td>6</td>
    </tr>
    <tr>
      <th>194</th>
      <td>7.6</td>
      <td>0.550</td>
      <td>0.21</td>
      <td>2.20</td>
      <td>0.071</td>
      <td>7.0</td>
      <td>28.0</td>
      <td>0.99640</td>
      <td>3.28</td>
      <td>0.55</td>
      <td>9.7</td>
      <td>5</td>
    </tr>
    <tr>
      <th>579</th>
      <td>10.6</td>
      <td>0.310</td>
      <td>0.49</td>
      <td>2.20</td>
      <td>0.063</td>
      <td>18.0</td>
      <td>40.0</td>
      <td>0.99760</td>
      <td>3.14</td>
      <td>0.51</td>
      <td>9.8</td>
      <td>6</td>
    </tr>
    <tr>
      <th>611</th>
      <td>13.2</td>
      <td>0.380</td>
      <td>0.55</td>
      <td>2.70</td>
      <td>0.081</td>
      <td>5.0</td>
      <td>16.0</td>
      <td>1.00060</td>
      <td>2.98</td>
      <td>0.54</td>
      <td>9.4</td>
      <td>5</td>
    </tr>
    <tr>
      <th>1549</th>
      <td>7.4</td>
      <td>0.360</td>
      <td>0.30</td>
      <td>1.80</td>
      <td>0.074</td>
      <td>17.0</td>
      <td>24.0</td>
      <td>0.99419</td>
      <td>3.24</td>
      <td>0.70</td>
      <td>11.4</td>
      <td>8</td>
    </tr>
    <tr>
      <th>4</th>
      <td>7.4</td>
      <td>0.700</td>
      <td>0.00</td>
      <td>1.90</td>
      <td>0.076</td>
      <td>11.0</td>
      <td>34.0</td>
      <td>0.99780</td>
      <td>3.51</td>
      <td>0.56</td>
      <td>9.4</td>
      <td>5</td>
    </tr>
    <tr>
      <th>803</th>
      <td>7.7</td>
      <td>0.560</td>
      <td>0.08</td>
      <td>2.50</td>
      <td>0.114</td>
      <td>14.0</td>
      <td>46.0</td>
      <td>0.99710</td>
      <td>3.24</td>
      <td>0.66</td>
      <td>9.6</td>
      <td>6</td>
    </tr>
    <tr>
      <th>1287</th>
      <td>8.0</td>
      <td>0.600</td>
      <td>0.08</td>
      <td>2.60</td>
      <td>0.056</td>
      <td>3.0</td>
      <td>7.0</td>
      <td>0.99286</td>
      <td>3.22</td>
      <td>0.37</td>
      <td>13.0</td>
      <td>5</td>
    </tr>
  </tbody>
</table>
</div>




```python
wine.info()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 1599 entries, 0 to 1598
    Data columns (total 12 columns):
     #   Column                Non-Null Count  Dtype  
    ---  ------                --------------  -----  
     0   fixed acidity         1599 non-null   float64
     1   volatile acidity      1599 non-null   float64
     2   citric acid           1599 non-null   float64
     3   residual sugar        1599 non-null   float64
     4   chlorides             1599 non-null   float64
     5   free sulfur dioxide   1599 non-null   float64
     6   total sulfur dioxide  1599 non-null   float64
     7   density               1599 non-null   float64
     8   pH                    1599 non-null   float64
     9   sulphates             1599 non-null   float64
     10  alcohol               1599 non-null   float64
     11  quality               1599 non-null   int64  
    dtypes: float64(11), int64(1)
    memory usage: 150.0 KB
    


```python
wine.describe()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>fixed acidity</th>
      <th>volatile acidity</th>
      <th>citric acid</th>
      <th>residual sugar</th>
      <th>chlorides</th>
      <th>free sulfur dioxide</th>
      <th>total sulfur dioxide</th>
      <th>density</th>
      <th>pH</th>
      <th>sulphates</th>
      <th>alcohol</th>
      <th>quality</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>1599.000000</td>
      <td>1599.000000</td>
      <td>1599.000000</td>
      <td>1599.000000</td>
      <td>1599.000000</td>
      <td>1599.000000</td>
      <td>1599.000000</td>
      <td>1599.000000</td>
      <td>1599.000000</td>
      <td>1599.000000</td>
      <td>1599.000000</td>
      <td>1599.000000</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>8.319637</td>
      <td>0.527821</td>
      <td>0.270976</td>
      <td>2.538806</td>
      <td>0.087467</td>
      <td>15.874922</td>
      <td>46.467792</td>
      <td>0.996747</td>
      <td>3.311113</td>
      <td>0.658149</td>
      <td>10.422983</td>
      <td>5.636023</td>
    </tr>
    <tr>
      <th>std</th>
      <td>1.741096</td>
      <td>0.179060</td>
      <td>0.194801</td>
      <td>1.409928</td>
      <td>0.047065</td>
      <td>10.460157</td>
      <td>32.895324</td>
      <td>0.001887</td>
      <td>0.154386</td>
      <td>0.169507</td>
      <td>1.065668</td>
      <td>0.807569</td>
    </tr>
    <tr>
      <th>min</th>
      <td>4.600000</td>
      <td>0.120000</td>
      <td>0.000000</td>
      <td>0.900000</td>
      <td>0.012000</td>
      <td>1.000000</td>
      <td>6.000000</td>
      <td>0.990070</td>
      <td>2.740000</td>
      <td>0.330000</td>
      <td>8.400000</td>
      <td>3.000000</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>7.100000</td>
      <td>0.390000</td>
      <td>0.090000</td>
      <td>1.900000</td>
      <td>0.070000</td>
      <td>7.000000</td>
      <td>22.000000</td>
      <td>0.995600</td>
      <td>3.210000</td>
      <td>0.550000</td>
      <td>9.500000</td>
      <td>5.000000</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>7.900000</td>
      <td>0.520000</td>
      <td>0.260000</td>
      <td>2.200000</td>
      <td>0.079000</td>
      <td>14.000000</td>
      <td>38.000000</td>
      <td>0.996750</td>
      <td>3.310000</td>
      <td>0.620000</td>
      <td>10.200000</td>
      <td>6.000000</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>9.200000</td>
      <td>0.640000</td>
      <td>0.420000</td>
      <td>2.600000</td>
      <td>0.090000</td>
      <td>21.000000</td>
      <td>62.000000</td>
      <td>0.997835</td>
      <td>3.400000</td>
      <td>0.730000</td>
      <td>11.100000</td>
      <td>6.000000</td>
    </tr>
    <tr>
      <th>max</th>
      <td>15.900000</td>
      <td>1.580000</td>
      <td>1.000000</td>
      <td>15.500000</td>
      <td>0.611000</td>
      <td>72.000000</td>
      <td>289.000000</td>
      <td>1.003690</td>
      <td>4.010000</td>
      <td>2.000000</td>
      <td>14.900000</td>
      <td>8.000000</td>
    </tr>
  </tbody>
</table>
</div>




```python
print(wine.isnull().sum())
```

    fixed acidity           0
    volatile acidity        0
    citric acid             0
    residual sugar          0
    chlorides               0
    free sulfur dioxide     0
    total sulfur dioxide    0
    density                 0
    pH                      0
    sulphates               0
    alcohol                 0
    quality                 0
    dtype: int64
    


```python
wine.groupby('quality').mean()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>fixed acidity</th>
      <th>volatile acidity</th>
      <th>citric acid</th>
      <th>residual sugar</th>
      <th>chlorides</th>
      <th>free sulfur dioxide</th>
      <th>total sulfur dioxide</th>
      <th>density</th>
      <th>pH</th>
      <th>sulphates</th>
      <th>alcohol</th>
    </tr>
    <tr>
      <th>quality</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>3</th>
      <td>8.360000</td>
      <td>0.884500</td>
      <td>0.171000</td>
      <td>2.635000</td>
      <td>0.122500</td>
      <td>11.000000</td>
      <td>24.900000</td>
      <td>0.997464</td>
      <td>3.398000</td>
      <td>0.570000</td>
      <td>9.955000</td>
    </tr>
    <tr>
      <th>4</th>
      <td>7.779245</td>
      <td>0.693962</td>
      <td>0.174151</td>
      <td>2.694340</td>
      <td>0.090679</td>
      <td>12.264151</td>
      <td>36.245283</td>
      <td>0.996542</td>
      <td>3.381509</td>
      <td>0.596415</td>
      <td>10.265094</td>
    </tr>
    <tr>
      <th>5</th>
      <td>8.167254</td>
      <td>0.577041</td>
      <td>0.243686</td>
      <td>2.528855</td>
      <td>0.092736</td>
      <td>16.983847</td>
      <td>56.513950</td>
      <td>0.997104</td>
      <td>3.304949</td>
      <td>0.620969</td>
      <td>9.899706</td>
    </tr>
    <tr>
      <th>6</th>
      <td>8.347179</td>
      <td>0.497484</td>
      <td>0.273824</td>
      <td>2.477194</td>
      <td>0.084956</td>
      <td>15.711599</td>
      <td>40.869906</td>
      <td>0.996615</td>
      <td>3.318072</td>
      <td>0.675329</td>
      <td>10.629519</td>
    </tr>
    <tr>
      <th>7</th>
      <td>8.872362</td>
      <td>0.403920</td>
      <td>0.375176</td>
      <td>2.720603</td>
      <td>0.076588</td>
      <td>14.045226</td>
      <td>35.020101</td>
      <td>0.996104</td>
      <td>3.290754</td>
      <td>0.741256</td>
      <td>11.465913</td>
    </tr>
    <tr>
      <th>8</th>
      <td>8.566667</td>
      <td>0.423333</td>
      <td>0.391111</td>
      <td>2.577778</td>
      <td>0.068444</td>
      <td>13.277778</td>
      <td>33.444444</td>
      <td>0.995212</td>
      <td>3.267222</td>
      <td>0.767778</td>
      <td>12.094444</td>
    </tr>
  </tbody>
</table>
</div>




```python
sns.countplot(wine['quality'])
plt.show()
```


    
![png](output_6_0.png)
    



```python
wine.plot(kind='box',subplots = True, layout =(4,4),sharex = False)
```




    fixed acidity              Axes(0.125,0.712609;0.168478x0.167391)
    volatile acidity        Axes(0.327174,0.712609;0.168478x0.167391)
    citric acid             Axes(0.529348,0.712609;0.168478x0.167391)
    residual sugar          Axes(0.731522,0.712609;0.168478x0.167391)
    chlorides                  Axes(0.125,0.511739;0.168478x0.167391)
    free sulfur dioxide     Axes(0.327174,0.511739;0.168478x0.167391)
    total sulfur dioxide    Axes(0.529348,0.511739;0.168478x0.167391)
    density                 Axes(0.731522,0.511739;0.168478x0.167391)
    pH                          Axes(0.125,0.31087;0.168478x0.167391)
    sulphates                Axes(0.327174,0.31087;0.168478x0.167391)
    alcohol                  Axes(0.529348,0.31087;0.168478x0.167391)
    quality                  Axes(0.731522,0.31087;0.168478x0.167391)
    dtype: object




    
![png](output_7_1.png)
    



```python
wine['fixed acidity'].plot(kind = 'box')
```




    <Axes: >




    
![png](output_8_1.png)
    



```python
wine.hist(figsize=(10,10),bins=50)
plt.show()
```


    
![png](output_9_0.png)
    



```python
wine.sample(5)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>fixed acidity</th>
      <th>volatile acidity</th>
      <th>citric acid</th>
      <th>residual sugar</th>
      <th>chlorides</th>
      <th>free sulfur dioxide</th>
      <th>total sulfur dioxide</th>
      <th>density</th>
      <th>pH</th>
      <th>sulphates</th>
      <th>alcohol</th>
      <th>quality</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>1113</th>
      <td>8.9</td>
      <td>0.24</td>
      <td>0.39</td>
      <td>1.6</td>
      <td>0.074</td>
      <td>3.0</td>
      <td>10.0</td>
      <td>0.99698</td>
      <td>3.12</td>
      <td>0.59</td>
      <td>9.5</td>
      <td>6</td>
    </tr>
    <tr>
      <th>1360</th>
      <td>9.2</td>
      <td>0.54</td>
      <td>0.31</td>
      <td>2.3</td>
      <td>0.112</td>
      <td>11.0</td>
      <td>38.0</td>
      <td>0.99699</td>
      <td>3.24</td>
      <td>0.56</td>
      <td>10.9</td>
      <td>5</td>
    </tr>
    <tr>
      <th>632</th>
      <td>7.6</td>
      <td>0.41</td>
      <td>0.14</td>
      <td>3.0</td>
      <td>0.087</td>
      <td>21.0</td>
      <td>43.0</td>
      <td>0.99640</td>
      <td>3.32</td>
      <td>0.57</td>
      <td>10.5</td>
      <td>6</td>
    </tr>
    <tr>
      <th>413</th>
      <td>9.9</td>
      <td>0.40</td>
      <td>0.53</td>
      <td>6.7</td>
      <td>0.097</td>
      <td>6.0</td>
      <td>19.0</td>
      <td>0.99860</td>
      <td>3.27</td>
      <td>0.82</td>
      <td>11.7</td>
      <td>7</td>
    </tr>
    <tr>
      <th>1166</th>
      <td>9.9</td>
      <td>0.54</td>
      <td>0.26</td>
      <td>2.0</td>
      <td>0.111</td>
      <td>7.0</td>
      <td>60.0</td>
      <td>0.99709</td>
      <td>2.94</td>
      <td>0.98</td>
      <td>10.2</td>
      <td>5</td>
    </tr>
  </tbody>
</table>
</div>




```python
wine['quality'].unique()
```




    array([5, 6, 7, 4, 8, 3], dtype=int64)




```python
wine['goodquality'] = [1 if x >= 7 else 0 for x in wine['quality']]
wine.sample(5)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>fixed acidity</th>
      <th>volatile acidity</th>
      <th>citric acid</th>
      <th>residual sugar</th>
      <th>chlorides</th>
      <th>free sulfur dioxide</th>
      <th>total sulfur dioxide</th>
      <th>density</th>
      <th>pH</th>
      <th>sulphates</th>
      <th>alcohol</th>
      <th>quality</th>
      <th>goodquality</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>1268</th>
      <td>6.9</td>
      <td>0.41</td>
      <td>0.31</td>
      <td>2.0</td>
      <td>0.079</td>
      <td>21.0</td>
      <td>51.0</td>
      <td>0.99668</td>
      <td>3.47</td>
      <td>0.55</td>
      <td>9.5</td>
      <td>6</td>
      <td>0</td>
    </tr>
    <tr>
      <th>278</th>
      <td>10.3</td>
      <td>0.32</td>
      <td>0.45</td>
      <td>6.4</td>
      <td>0.073</td>
      <td>5.0</td>
      <td>13.0</td>
      <td>0.99760</td>
      <td>3.23</td>
      <td>0.82</td>
      <td>12.6</td>
      <td>8</td>
      <td>1</td>
    </tr>
    <tr>
      <th>518</th>
      <td>10.9</td>
      <td>0.21</td>
      <td>0.49</td>
      <td>2.8</td>
      <td>0.088</td>
      <td>11.0</td>
      <td>32.0</td>
      <td>0.99720</td>
      <td>3.22</td>
      <td>0.68</td>
      <td>11.7</td>
      <td>6</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1544</th>
      <td>8.4</td>
      <td>0.37</td>
      <td>0.43</td>
      <td>2.3</td>
      <td>0.063</td>
      <td>12.0</td>
      <td>19.0</td>
      <td>0.99550</td>
      <td>3.17</td>
      <td>0.81</td>
      <td>11.2</td>
      <td>7</td>
      <td>1</td>
    </tr>
    <tr>
      <th>379</th>
      <td>8.3</td>
      <td>0.42</td>
      <td>0.38</td>
      <td>2.5</td>
      <td>0.094</td>
      <td>24.0</td>
      <td>60.0</td>
      <td>0.99790</td>
      <td>3.31</td>
      <td>0.70</td>
      <td>10.8</td>
      <td>6</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
</div>




```python
#separate deendent and independent variables
x = wine.drop(['quality','goodquality'],axis = 1)
y = wine['goodquality']
```


```python
wine ['goodquality'].value_counts()
```




    0    1382
    1     217
    Name: goodquality, dtype: int64




```python
x
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>fixed acidity</th>
      <th>volatile acidity</th>
      <th>citric acid</th>
      <th>residual sugar</th>
      <th>chlorides</th>
      <th>free sulfur dioxide</th>
      <th>total sulfur dioxide</th>
      <th>density</th>
      <th>pH</th>
      <th>sulphates</th>
      <th>alcohol</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>7.4</td>
      <td>0.700</td>
      <td>0.00</td>
      <td>1.9</td>
      <td>0.076</td>
      <td>11.0</td>
      <td>34.0</td>
      <td>0.99780</td>
      <td>3.51</td>
      <td>0.56</td>
      <td>9.4</td>
    </tr>
    <tr>
      <th>1</th>
      <td>7.8</td>
      <td>0.880</td>
      <td>0.00</td>
      <td>2.6</td>
      <td>0.098</td>
      <td>25.0</td>
      <td>67.0</td>
      <td>0.99680</td>
      <td>3.20</td>
      <td>0.68</td>
      <td>9.8</td>
    </tr>
    <tr>
      <th>2</th>
      <td>7.8</td>
      <td>0.760</td>
      <td>0.04</td>
      <td>2.3</td>
      <td>0.092</td>
      <td>15.0</td>
      <td>54.0</td>
      <td>0.99700</td>
      <td>3.26</td>
      <td>0.65</td>
      <td>9.8</td>
    </tr>
    <tr>
      <th>3</th>
      <td>11.2</td>
      <td>0.280</td>
      <td>0.56</td>
      <td>1.9</td>
      <td>0.075</td>
      <td>17.0</td>
      <td>60.0</td>
      <td>0.99800</td>
      <td>3.16</td>
      <td>0.58</td>
      <td>9.8</td>
    </tr>
    <tr>
      <th>4</th>
      <td>7.4</td>
      <td>0.700</td>
      <td>0.00</td>
      <td>1.9</td>
      <td>0.076</td>
      <td>11.0</td>
      <td>34.0</td>
      <td>0.99780</td>
      <td>3.51</td>
      <td>0.56</td>
      <td>9.4</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>1594</th>
      <td>6.2</td>
      <td>0.600</td>
      <td>0.08</td>
      <td>2.0</td>
      <td>0.090</td>
      <td>32.0</td>
      <td>44.0</td>
      <td>0.99490</td>
      <td>3.45</td>
      <td>0.58</td>
      <td>10.5</td>
    </tr>
    <tr>
      <th>1595</th>
      <td>5.9</td>
      <td>0.550</td>
      <td>0.10</td>
      <td>2.2</td>
      <td>0.062</td>
      <td>39.0</td>
      <td>51.0</td>
      <td>0.99512</td>
      <td>3.52</td>
      <td>0.76</td>
      <td>11.2</td>
    </tr>
    <tr>
      <th>1596</th>
      <td>6.3</td>
      <td>0.510</td>
      <td>0.13</td>
      <td>2.3</td>
      <td>0.076</td>
      <td>29.0</td>
      <td>40.0</td>
      <td>0.99574</td>
      <td>3.42</td>
      <td>0.75</td>
      <td>11.0</td>
    </tr>
    <tr>
      <th>1597</th>
      <td>5.9</td>
      <td>0.645</td>
      <td>0.12</td>
      <td>2.0</td>
      <td>0.075</td>
      <td>32.0</td>
      <td>44.0</td>
      <td>0.99547</td>
      <td>3.57</td>
      <td>0.71</td>
      <td>10.2</td>
    </tr>
    <tr>
      <th>1598</th>
      <td>6.0</td>
      <td>0.310</td>
      <td>0.47</td>
      <td>3.6</td>
      <td>0.067</td>
      <td>18.0</td>
      <td>42.0</td>
      <td>0.99549</td>
      <td>3.39</td>
      <td>0.66</td>
      <td>11.0</td>
    </tr>
  </tbody>
</table>
<p>1599 rows × 11 columns</p>
</div>




```python
print(y)
```

    0       0
    1       0
    2       0
    3       0
    4       0
           ..
    1594    0
    1595    0
    1596    0
    1597    0
    1598    0
    Name: goodquality, Length: 1599, dtype: int64
    


```python
model_res=pd.DataFrame(columns=['Model','Score'])
```


```python

```
